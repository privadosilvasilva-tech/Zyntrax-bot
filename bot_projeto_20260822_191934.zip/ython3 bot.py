discord.py>=2.4.0
python-dotenv>=1.0.0
