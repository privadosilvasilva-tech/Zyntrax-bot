import discord
from typing import Callable, List

class ModalBuscaCanais(discord.ui.Modal, title="🔍 Buscar Canal"):
    def __init__(self, guild: discord.Guild, callback: Callable, min_results: int = 1):
        super().__init__()
        self.guild = guild
        self.callback = callback
        self.min_results = min_results
        self.busca_input = discord.ui.TextInput(
            label="Digite o nome do canal (parcial)",
            placeholder="Ex: geral, logs, moderação...",
            min_length=1,
            max_length=100
        )
        self.add_item(self.busca_input)
    
    async def on_submit(self, interaction: discord.Interaction):
        termo = self.busca_input.value.lower()
        
        # Filtrar canais pelo termo
        canais_filtrados = [
            c for c in self.guild.text_channels 
            if termo in c.name.lower()
        ][:25]  # Máximo 25 opções
        
        if not canais_filtrados:
            await interaction.response.send_message(
                f"❌ Nenhum canal encontrado com '{termo}'",
                ephemeral=True
            )
            return
        
        options = [
            discord.SelectOption(label=c.name[:100], value=str(c.id))
            for c in canais_filtrados
        ]
        
        select = discord.ui.Select(
            options=options,
            placeholder=f"Selecione um canal ({len(options)} encontrado(s))",
            min_values=1,
            max_values=1
        )
        
        async def select_callback(inter: discord.Interaction):
            await self.callback(inter, int(select.values[0]))
        
        select.callback = select_callback
        view = discord.ui.View()
        view.add_item(select)
        
        await interaction.response.send_message(
            f"✅ {len(options)} canal(is) encontrado(s):",
            view=view,
            ephemeral=True
        )

class ModalBuscaCargos(discord.ui.Modal, title="🔍 Buscar Cargo"):
    def __init__(self, guild: discord.Guild, callback: Callable):
        super().__init__()
        self.guild = guild
        self.callback = callback
        self.busca_input = discord.ui.TextInput(
            label="Digite o nome do cargo (parcial)",
            placeholder="Ex: Moderador, Admin, VIP...",
            min_length=1,
            max_length=100
        )
        self.add_item(self.busca_input)
    
    async def on_submit(self, interaction: discord.Interaction):
        termo = self.busca_input.value.lower()
        
        # Filtrar cargos pelo termo
        cargos_filtrados = [
            r for r in self.guild.roles 
            if r.name != "@everyone" and termo in r.name.lower()
        ][:25]  # Máximo 25 opções
        
        if not cargos_filtrados:
            await interaction.response.send_message(
                f"❌ Nenhum cargo encontrado com '{termo}'",
                ephemeral=True
            )
            return
        
        options = [
            discord.SelectOption(label=r.name[:100], value=str(r.id))
            for r in cargos_filtrados
        ]
        
        select = discord.ui.Select(
            options=options,
            placeholder=f"Selecione um cargo ({len(options)} encontrado(s))",
            min_values=1,
            max_values=1
        )
        
        async def select_callback(inter: discord.Interaction):
            await self.callback(inter, int(select.values[0]))
        
        select.callback = select_callback
        view = discord.ui.View()
        view.add_item(select)
        
        await interaction.response.send_message(
            f"✅ {len(options)} cargo(s) encontrado(s):",
            view=view,
            ephemeral=True
        )
