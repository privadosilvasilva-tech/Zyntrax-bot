-- Bucket público para fotos anexadas aos avisos (o próprio painel admin cuida
-- de quem pode postar; leitura é pública pois avisos aparecem pra turma toda).
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'avisos',
  'avisos',
  true,
  5242880, -- 5 MB
  ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/gif']
)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Fotos de avisos sao publicas"
ON storage.objects FOR SELECT
USING (bucket_id = 'avisos');

CREATE POLICY "Staff envia foto de aviso"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'avisos' AND private.is_staff(auth.uid()));

CREATE POLICY "Staff atualiza foto de aviso"
ON storage.objects FOR UPDATE TO authenticated
USING (bucket_id = 'avisos' AND private.is_staff(auth.uid()))
WITH CHECK (bucket_id = 'avisos' AND private.is_staff(auth.uid()));

CREATE POLICY "Staff apaga foto de aviso"
ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'avisos' AND private.is_staff(auth.uid()));
