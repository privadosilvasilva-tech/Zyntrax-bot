import { createStart, createMiddleware } from "@tanstack/react-start";

import { renderErrorPage } from "./lib/error-page";
import { attachSupabaseAuth } from "@/integrations/supabase/auth-attacher";

const errorMiddleware = createMiddleware().server(async ({ next }) => {
  try {
    return await next();
  } catch (error) {
    if (error != null && typeof error === "object" && "statusCode" in error) {
      throw error;
    }
    console.error(error);
    return new Response(renderErrorPage(), {
      status: 500,
      headers: { "content-type": "text/html; charset=utf-8" },
    });
  }
});

// CSRF middleware was removed: this app authenticates every server-function
// call with an explicit Bearer token (see auth-middleware.ts), never relying
// on ambient cookies, so it isn't exposed to cross-site request forgery.
// The Origin/Referer/Sec-Fetch-Site checks were instead producing false
// "Forbidden" rejections for users behind mobile-carrier proxies that strip
// or rewrite those headers (e.g. VIVO no Brasil).
export const startInstance = createStart(() => ({
  functionMiddleware: [attachSupabaseAuth],
  requestMiddleware: [errorMiddleware],
}));
