import { Megaphone } from "lucide-react";

/** TAG chamativa para destacar avisos: gradiente animado + brilho pulsante + ícone balançando. */
export function AvisoTag({ size = "md", className = "" }: { size?: "sm" | "md"; className?: string }) {
  return (
    <span
      className={`aviso-tag inline-flex items-center gap-1.5 whitespace-nowrap rounded-full font-bold uppercase tracking-wide text-white ${
        size === "sm" ? "px-2 py-0.5 text-[0.6rem]" : "px-3 py-1.5 text-xs"
      } ${className}`}
    >
      <Megaphone className={`aviso-tag-icon ${size === "sm" ? "h-3 w-3" : "h-3.5 w-3.5"}`} aria-hidden />
      Aviso
    </span>
  );
}
