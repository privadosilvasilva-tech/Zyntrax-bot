import { useEffect, useRef, useState } from "react";
import { Volume2, VolumeX } from "lucide-react";
import { toast } from "sonner";

declare global {
  interface Window {
    YT?: any;
    onYouTubeIframeAPIReady?: () => void;
  }
}

const YT_ERROR_REASONS: Record<number, string> = {
  2: "ID de vídeo inválido (verifique se colou só o ID, não a URL inteira)",
  5: "Erro no player em HTML5",
  100: "Vídeo não encontrado ou removido",
  101: "O dono do vídeo não permite reprodução em outros sites (embed bloqueado)",
  150: "O dono do vídeo não permite reprodução em outros sites (embed bloqueado)",
};

/** Aceita tanto um ID puro quanto uma URL colada (youtube.com/watch?v=, youtu.be/, /embed/). */
function extractVideoId(input: string): string {
  const trimmed = input.trim();
  if (!trimmed) return "";
  if (!trimmed.includes("/") && !trimmed.includes("?")) return trimmed;
  const patterns = [/[?&]v=([^&]+)/, /youtu\.be\/([^?&]+)/, /\/embed\/([^?&]+)/, /\/shorts\/([^?&]+)/];
  for (const p of patterns) {
    const m = trimmed.match(p);
    if (m) return m[1];
  }
  return trimmed;
}

export function BackgroundMusic({ videoId: rawVideoId }: { videoId: string }) {
  const videoId = extractVideoId(rawVideoId);
  const playerRef = useRef<any>(null);
  const [ready, setReady] = useState(false);
  const [muted, setMuted] = useState(true);

  useEffect(() => {
    if (!videoId) return;
    let cancelled = false;

    const watchdog = window.setTimeout(() => {
      if (!cancelled && !playerRef.current) {
        toast.error("Música de fundo: o player do YouTube não carregou (rede ou bloqueador de anúncios?)");
      }
    }, 6000);

    function create() {
      if (cancelled || playerRef.current) return;
      window.clearTimeout(watchdog);
      playerRef.current = new window.YT.Player("byandry-bgm", {
        videoId,
        playerVars: { autoplay: 1, controls: 0, loop: 1, playlist: videoId, playsinline: 1 },
        events: {
          onReady: (e: any) => {
            e.target.mute();
            e.target.playVideo();
            setReady(true);
          },
          onStateChange: (e: any) => {
            if (e.data === 0) e.target.playVideo();
          },
          onError: (e: any) => {
            const reason = YT_ERROR_REASONS[e.data] ?? `código ${e.data}`;
            console.error("[BackgroundMusic] Falha ao carregar o vídeo:", reason);
            toast.error(`Música de fundo: ${reason}`);
          },
        },
      });
    }

    if (window.YT?.Player) {
      create();
    } else {
      const prev = window.onYouTubeIframeAPIReady;
      window.onYouTubeIframeAPIReady = () => {
        prev?.();
        create();
      };
      if (!document.getElementById("yt-iframe-api")) {
        const s = document.createElement("script");
        s.id = "yt-iframe-api";
        s.src = "https://www.youtube.com/iframe_api";
        document.body.appendChild(s);
      }
    }

    return () => {
      cancelled = true;
      window.clearTimeout(watchdog);
    };
  }, [videoId]);

  if (!videoId) return null;

  function toggle() {
    const p = playerRef.current;
    if (!p) return;
    if (muted) {
      p.unMute();
      p.setVolume(35);
      p.playVideo();
      setMuted(false);
    } else {
      p.mute();
      setMuted(true);
    }
  }

  return (
    <>
      <div
        id="byandry-bgm"
        aria-hidden="true"
        className="pointer-events-none absolute h-px w-px overflow-hidden opacity-0"
      />
      <button
        type="button"
        onClick={toggle}
        disabled={!ready}
        aria-label={muted ? "Ativar música de fundo" : "Desligar música de fundo"}
        title={muted ? "Ativar música" : "Desligar música"}
        className="fixed right-4 top-4 z-50 flex h-11 w-11 items-center justify-center rounded-full border border-border bg-card/80 text-foreground shadow-[var(--shadow-soft)] backdrop-blur transition-all hover:scale-105 hover:text-primary disabled:opacity-40"
      >
        {muted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
      </button>
    </>
  );
}
