import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { BackgroundMusic } from "@/components/BackgroundMusic";
import { getSetupState } from "@/lib/account.functions";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    const { data, error } = await supabase.auth.getUser();
    if (error || !data.user) throw redirect({ to: "/" });
    return { user: data.user };
  },
  component: AuthenticatedLayout,
});

function AuthenticatedLayout() {
  // Rendered once per login (not per page), unlike AppShell which each page
  // mounts fresh — so the YouTube player lives here and survives navigation
  // between pages instead of restarting on every route change.
  const { data: settings } = useQuery({
    queryKey: ["settings"],
    queryFn: () => getSetupState(),
    staleTime: 5 * 60 * 1000,
  });

  return (
    <>
      <BackgroundMusic videoId={settings?.bgmVideoId ?? ""} />
      <Outlet />
    </>
  );
}
