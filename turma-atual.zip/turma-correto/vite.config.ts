import { defineConfig } from "vite";
import { nitro } from "nitro/vite";
import { tanstackStart } from "@tanstack/react-start/plugin/vite";
import viteReact from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import { fileURLToPath } from "node:url";

// Substitui o wrapper interno do Lovable (@lovable.dev/vite-tanstack-config),
// que só funciona dentro do ambiente de build do Lovable. Aqui montamos a
// mesma coisa na mão, com pacotes públicos:
//   - tanstackStart(): TanStack Start + roteamento (usa src/server.ts como
//     entrada do servidor automaticamente, sem precisar configurar nada)
//   - viteReact(): suporte a React/JSX
//   - tailwindcss(): Tailwind v4 via plugin oficial do Vite
//   - nitro(): build do servidor, gera .output/server/index.mjs (mesmo
//     comando de start já configurado no Render)
//   - alias "@": aponta pra ./src, igual ao que o tsconfig.json já define

export default defineConfig({
  resolve: {
    alias: {
      "@": fileURLToPath(new URL("./src", import.meta.url)),
    },
  },
  plugins: [tanstackStart(), viteReact(), tailwindcss(), nitro()],
});
