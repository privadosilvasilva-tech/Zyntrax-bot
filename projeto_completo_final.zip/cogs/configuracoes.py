import discord
from discord import app_commands
from discord.ext import commands
import json
import os

CONFIG_FILE = "config/configuracoes_config.json"

def load_cfg():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

def save_cfg(data):
    os.makedirs("config", exist_ok=True)
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)

class Configuracoes(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="configuracoes", description="Painel geral")
    async def config_cmd(self, interaction: discord.Interaction):
        if interaction.user.id != interaction.guild.owner_id:
            embed = discord.Embed(title="❌ Sem Permissão", color=0xFF0000)
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        embed = discord.Embed(
            title="⚙️ Configurações do Servidor",
            description="Painel de configuração geral",
            color=0x3498DB
        )
        embed.set_footer(text="Nix / Zyntrax Support")
        await interaction.response.send_message(embed=embed, ephemeral=True)

async def setup(bot):
    await bot.add_cog(Configuracoes(bot))
