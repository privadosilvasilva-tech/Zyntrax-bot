import discord
from discord import app_commands
from discord.ext import commands
import json
import os
import asyncio

CONFIG_FILE = "config/verificacao_config.json"

def load_cfg():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

def save_cfg(data):
    os.makedirs("config", exist_ok=True)
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)

class Verificacao(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="verificacao", description="Config verificação")
    async def verificacao_cmd(self, interaction: discord.Interaction):
        if interaction.user.id != interaction.guild.owner_id:
            await interaction.response.send_message("❌", ephemeral=True)
            return
        
        embed = discord.Embed(title="⚙️ Verificação", color=0x2ECC71)
        await interaction.response.send_message(embed=embed, view=Painel(self.bot, interaction.guild))

class Painel(discord.ui.View):
    def __init__(self, bot, guild):
        super().__init__(timeout=300)
        self.bot = bot
        self.guild = guild
    
    @discord.ui.button(label="📌 Canal", style=discord.ButtonStyle.primary)
    async def btn1(self, inter, btn):
        opts = [discord.SelectOption(label=c.name, value=str(c.id)) for c in self.guild.text_channels[:25]]
        s = discord.ui.Select(options=opts)
        async def cb(i):
            c = load_cfg()
            c[str(i.guild_id)] = c.get(str(i.guild_id), {})
            c[str(i.guild_id)]["canal"] = s.values[0]
            save_cfg(c)
            await i.response.send_message("✅", ephemeral=True)
        s.callback = cb
        v = discord.ui.View()
        v.add_item(s)
        await inter.response.send_message("Qual?", view=v, ephemeral=True)
    
    @discord.ui.button(label="📁 Categoria", style=discord.ButtonStyle.primary)
    async def btn2(self, inter, btn):
        opts = [discord.SelectOption(label=c.name, value=str(c.id)) for c in self.guild.categories[:25]]
        s = discord.ui.Select(options=opts)
        async def cb(i):
            c = load_cfg()
            c[str(i.guild_id)] = c.get(str(i.guild_id), {})
            c[str(i.guild_id)]["categoria"] = s.values[0]
            save_cfg(c)
            await i.response.send_message("✅", ephemeral=True)
        s.callback = cb
        v = discord.ui.View()
        v.add_item(s)
        await inter.response.send_message("Qual?", view=v, ephemeral=True)
    
    @discord.ui.button(label="👤 Cargo Não", style=discord.ButtonStyle.success)
    async def btn3(self, inter, btn):
        opts = [discord.SelectOption(label=c.name, value=str(c.id)) for c in self.guild.roles[:25]]
        s = discord.ui.Select(options=opts)
        async def cb(i):
            c = load_cfg()
            c[str(i.guild_id)] = c.get(str(i.guild_id), {})
            c[str(i.guild_id)]["cargo_nao"] = s.values[0]
            save_cfg(c)
            await i.response.send_message("✅", ephemeral=True)
        s.callback = cb
        v = discord.ui.View()
        v.add_item(s)
        await inter.response.send_message("Qual?", view=v, ephemeral=True)
    
    @discord.ui.button(label="✅ Cargo Sim", style=discord.ButtonStyle.success)
    async def btn4(self, inter, btn):
        opts = [discord.SelectOption(label=c.name, value=str(c.id)) for c in self.guild.roles[:25]]
        s = discord.ui.Select(options=opts)
        async def cb(i):
            c = load_cfg()
            c[str(i.guild_id)] = c.get(str(i.guild_id), {})
            c[str(i.guild_id)]["cargo_sim"] = s.values[0]
            save_cfg(c)
            await i.response.send_message("✅", ephemeral=True)
        s.callback = cb
        v = discord.ui.View()
        v.add_item(s)
        await inter.response.send_message("Qual?", view=v, ephemeral=True)
    
    @discord.ui.button(label="🚀 ATIVAR", style=discord.ButtonStyle.green)
    async def btn5(self, inter, btn):
        c = load_cfg()
        gid = str(inter.guild_id)
        c[gid] = c.get(gid, {})
        
        if not c[gid].get("canal") or not c[gid].get("categoria"):
            await inter.response.send_message("❌ Falta config", ephemeral=True)
            return
        
        c[gid]["ativo"] = True
        save_cfg(c)
        
        canal = inter.guild.get_channel(int(c[gid]["canal"]))
        if canal:
            embed = discord.Embed(title="🔐 Verificação", description="Clique abaixo", color=0x2ECC71)
            try:
                await canal.send(embed=embed, view=BotaoVerif(gid))
            except:
                pass
        
        await inter.response.send_message("✅ ATIVO", ephemeral=True)

class BotaoVerif(discord.ui.View):
    def __init__(self, gid):
        super().__init__(timeout=None)
        self.gid = gid
    
    @discord.ui.button(label="✅ Verificar", style=discord.ButtonStyle.green)
    async def verif(self, interaction: discord.Interaction, btn):
        c = load_cfg().get(self.gid, {})
        
        if not c.get("ativo"):
            await interaction.response.send_message("❌", ephemeral=True)
            return
        
        member = interaction.user
        cargo_sim = interaction.guild.get_role(int(c["cargo_sim"]))
        
        if not cargo_sim:
            await interaction.response.send_message("❌", ephemeral=True)
            return
        
        if cargo_sim in member.roles:
            await interaction.response.send_message("✅ Já!", ephemeral=True)
            return
        
        if c.get("cargo_nao"):
            cargo_nao = interaction.guild.get_role(int(c["cargo_nao"]))
            if cargo_nao and cargo_nao in member.roles:
                await member.remove_roles(cargo_nao)
        
        await member.add_roles(cargo_sim)
        await interaction.response.send_message("✅ OK!", ephemeral=True)
        
        # DM após 5 segundos
        async def enviar_dm():
            await asyncio.sleep(5)
            try:
                e = discord.Embed(title="🎉 Verificado!", description="Bem-vindo!", color=0x2ECC71)
                await member.send(embed=e)
            except:
                pass
        
        asyncio.create_task(enviar_dm())

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        c = load_cfg().get(str(member.guild.id), {})
        if c.get("ativo") and c.get("cargo_nao"):
            cargo = member.guild.get_role(int(c["cargo_nao"]))
            if cargo:
                try:
                    await member.add_roles(cargo)
                except:
                    pass

async def setup(bot):
    await bot.add_cog(Verificacao(bot))
