'use client';

import { useState } from 'react';
import { useModuleConfig } from './useModuleConfig';
import { ModuleShell, FieldGroup, Field } from './ModuleShell';
import { Toggle } from './Toggle';
import { RoleMultiSelect } from './RoleMultiSelect';

interface ModConfig {
  antispam?: { enabled: boolean; repetition_limit: number; caps_limit: number };
  antiraid?: { enabled: boolean; join_limit: number; time_window: number };
  antilink?: { enabled: boolean; allowed_roles: (string | number)[]; message: string };
}
type Data = Record<string, ModConfig>;

const SUBTABS = [
  { id: 'antispam', label: '🧯 Anti-Spam' },
  { id: 'antiraid', label: '🛡️ Anti-Raid' },
  { id: 'antilink', label: '🔗 Anti-Link' },
] as const;

export function ModerationForm({ guildId }: { guildId: string }) {
  const { data, save, state, error } = useModuleConfig<Data>(guildId, 'moderacao');
  const [tab, setTab] = useState<(typeof SUBTABS)[number]['id']>('antispam');

  if (!data) return <ModuleShell title="Moderação" description="Carregando..." state="loading">{null}</ModuleShell>;

  const guildData = data[guildId] ?? {};

  function updateGuild(patch: Partial<ModConfig>) {
    save({ ...data, [guildId]: { ...guildData, ...patch } });
  }

  const antispam = {
    enabled: guildData.antispam?.enabled ?? false,
    repetition_limit: guildData.antispam?.repetition_limit ?? 5,
    caps_limit: guildData.antispam?.caps_limit ?? 75,
  };
  const antiraid = {
    enabled: guildData.antiraid?.enabled ?? false,
    join_limit: guildData.antiraid?.join_limit ?? 6,
    time_window: guildData.antiraid?.time_window ?? 20,
  };
  const antilink = {
    enabled: guildData.antilink?.enabled ?? false,
    allowed_roles: guildData.antilink?.allowed_roles ?? [],
    message: guildData.antilink?.message ?? '',
  };

  return (
    <ModuleShell title="Moderação" description="Proteções automáticas do servidor" state={state} error={error}>
      <div className="flex gap-2 mb-5 flex-wrap">
        {SUBTABS.map((t) => (
          <button key={t.id} className="tab-pill" data-active={tab === t.id} onClick={() => setTab(t.id)} type="button">
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'antispam' && (
        <FieldGroup title="Anti-Spam">
          <Toggle
            checked={antispam.enabled}
            onChange={(v) => updateGuild({ antispam: { ...antispam, enabled: v } })}
            label="Ativo"
            description="Detecta mensagens repetidas e uso excessivo de CAPS LOCK"
          />
          <Field label={`Limite de mensagens repetidas: ${antispam.repetition_limit}`}>
            <input
              type="range"
              min={2}
              max={15}
              className="w-full accent-[#5865f2]"
              value={antispam.repetition_limit}
              onChange={(e) => updateGuild({ antispam: { ...antispam, repetition_limit: Number(e.target.value) } })}
            />
          </Field>
          <Field label={`Limite de CAPS LOCK: ${antispam.caps_limit}%`}>
            <input
              type="range"
              min={30}
              max={100}
              className="w-full accent-[#5865f2]"
              value={antispam.caps_limit}
              onChange={(e) => updateGuild({ antispam: { ...antispam, caps_limit: Number(e.target.value) } })}
            />
          </Field>
        </FieldGroup>
      )}

      {tab === 'antiraid' && (
        <FieldGroup title="Anti-Raid">
          <Toggle
            checked={antiraid.enabled}
            onChange={(v) => updateGuild({ antiraid: { ...antiraid, enabled: v } })}
            label="Ativo"
            description="Detecta entradas em massa em pouco tempo (possível raid)"
          />
          <Field label={`Entradas suspeitas: ${antiraid.join_limit} membros`}>
            <input
              type="range"
              min={2}
              max={30}
              className="w-full accent-[#5865f2]"
              value={antiraid.join_limit}
              onChange={(e) => updateGuild({ antiraid: { ...antiraid, join_limit: Number(e.target.value) } })}
            />
          </Field>
          <Field label={`Janela de tempo: ${antiraid.time_window}s`}>
            <input
              type="range"
              min={5}
              max={120}
              className="w-full accent-[#5865f2]"
              value={antiraid.time_window}
              onChange={(e) => updateGuild({ antiraid: { ...antiraid, time_window: Number(e.target.value) } })}
            />
          </Field>
        </FieldGroup>
      )}

      {tab === 'antilink' && (
        <FieldGroup title="Anti-Link">
          <Toggle
            checked={antilink.enabled}
            onChange={(v) => updateGuild({ antilink: { ...antilink, enabled: v } })}
            label="Ativo"
            description="Bloqueia convites de outros servidores automaticamente"
          />
          <Field label="Cargos liberados (podem postar links)">
            <RoleMultiSelect
              guildId={guildId}
              value={antilink.allowed_roles}
              onChange={(roles) => updateGuild({ antilink: { ...antilink, allowed_roles: roles } })}
            />
          </Field>
          <Field label="Mensagem de aviso">
            <input
              className="input-base"
              value={antilink.message}
              onChange={(e) => updateGuild({ antilink: { ...antilink, message: e.target.value } })}
            />
          </Field>
        </FieldGroup>
      )}
    </ModuleShell>
  );
}
