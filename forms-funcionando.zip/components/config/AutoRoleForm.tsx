'use client';

import { useModuleConfig } from './useModuleConfig';
import { ModuleShell, FieldGroup, Field } from './ModuleShell';
import { Toggle } from './Toggle';
import { RoleMultiSelect } from './RoleMultiSelect';

interface GuildAutoCargo {
  enabled: boolean;
  cargos: (string | number)[];
}
type Data = Record<string, GuildAutoCargo>;

export function AutoRoleForm({ guildId }: { guildId: string }) {
  const { data, save, state, error } = useModuleConfig<Data>(guildId, 'autocargo');

  if (!data) return <ModuleShell title="Auto-Cargo" description="Carregando..." state="loading">{null}</ModuleShell>;

  const raw = data[guildId];
  const guildData: GuildAutoCargo = { enabled: raw?.enabled ?? false, cargos: raw?.cargos ?? [] };

  function update(patch: Partial<GuildAutoCargo>) {
    save({ ...data, [guildId]: { ...guildData, ...patch } });
  }

  return (
    <ModuleShell
      title="Auto-Cargo"
      description="Cargos aplicados automaticamente a quem entra no servidor"
      state={state}
      error={error}
    >
      <FieldGroup>
        <Toggle
          checked={guildData.enabled}
          onChange={(v) => update({ enabled: v })}
          label="Ativo"
          description="Aplica os cargos abaixo assim que um membro entra"
        />
        <Field label="Cargos a aplicar">
          <RoleMultiSelect guildId={guildId} value={guildData.cargos} onChange={(cargos) => update({ cargos })} />
        </Field>
      </FieldGroup>
    </ModuleShell>
  );
}
