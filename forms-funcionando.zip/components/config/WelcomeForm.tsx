'use client';

import { useMemo, useState } from 'react';
import { useModuleConfig } from './useModuleConfig';
import { ModuleShell, FieldGroup, Field } from './ModuleShell';
import { Toggle } from './Toggle';
import { DiscordSelect } from './DiscordSelect';

interface WelcomeMessage {
  enabled: boolean;
  channel_id: number | string | null;
  title: string | null;
  description: string | null;
  footer: string | null;
  color: number | null;
  thumbnail: string | null;
  image: string | null;
  ping_member: boolean;
}

type RecepcaoConfig = Record<string, { entrada?: WelcomeMessage; saida?: WelcomeMessage }>;

const BLANK: WelcomeMessage = {
  enabled: false,
  channel_id: null,
  title: '',
  description: '',
  footer: '',
  color: 0x5865f2,
  thumbnail: '',
  image: '',
  ping_member: false,
};

function toHex(color: number | null | undefined) {
  return '#' + (color ?? 0x5865f2).toString(16).padStart(6, '0');
}
function fromHex(hex: string) {
  return parseInt(hex.replace('#', ''), 16);
}

const VARS = ['{membro}', '{membro_mencao}', '{membro_tag}', '{servidor}', '{contagem_membros}', '{data_entrada}'];

export function WelcomeForm({ guildId }: { guildId: string }) {
  const { data, save, state, error } = useModuleConfig<RecepcaoConfig>(guildId, 'recepcao');
  const [tab, setTab] = useState<'entrada' | 'saida'>('entrada');

  const guildData = data?.[guildId] ?? {};
  const msg: WelcomeMessage = { ...BLANK, ...(guildData[tab] ?? {}) };

  const preview = useMemo(
    () => ({
      title: (msg.title || '').replace(/\{[a-z_]+\}/g, (m) =>
        ({ '{membro}': 'NovoMembro', '{servidor}': 'Meu Servidor' }[m] || m)
      ),
      description: (msg.description || 'Sua mensagem aparece aqui...').slice(0, 300),
    }),
    [msg.title, msg.description]
  );

  if (!data) return <ModuleShell title="Boas-vindas" description="Carregando..." state="loading">{null}</ModuleShell>;

  function update(patch: Partial<WelcomeMessage>) {
    const next: RecepcaoConfig = {
      ...data,
      [guildId]: {
        ...guildData,
        [tab]: { ...msg, ...patch },
      },
    };
    save(next);
  }

  return (
    <ModuleShell
      title="Boas-vindas"
      description="Mensagens automáticas de entrada e saída de membros"
      state={state}
      error={error}
    >
      <div className="flex gap-2 mb-5">
        {(['entrada', 'saida'] as const).map((t) => (
          <button
            key={t}
            className="tab-pill"
            data-active={tab === t}
            onClick={() => setTab(t)}
            type="button"
          >
            {t === 'entrada' ? '👋 Entrada' : '💙 Saída'}
          </button>
        ))}
      </div>

      <FieldGroup>
        <Toggle
          checked={msg.enabled}
          onChange={(v) => update({ enabled: v })}
          label={tab === 'entrada' ? 'Mensagem de boas-vindas ativa' : 'Mensagem de saída ativa'}
          description="Liga ou desliga esse aviso sem apagar o texto configurado"
        />
      </FieldGroup>

      <div className="grid md:grid-cols-2 gap-5">
        <div>
          <FieldGroup title="Onde enviar">
            <Field label="Canal">
              <DiscordSelect
                guildId={guildId}
                kind="channels"
                value={msg.channel_id ? String(msg.channel_id) : null}
                onChange={(v) => update({ channel_id: v })}
              />
            </Field>
            <Toggle
              checked={msg.ping_member}
              onChange={(v) => update({ ping_member: v })}
              label="Marcar o membro"
              description="Envia a mensagem mencionando @o-membro"
            />
          </FieldGroup>

          <FieldGroup title="Conteúdo">
            <Field label="Título">
              <input
                className="input-base"
                value={msg.title ?? ''}
                onChange={(e) => update({ title: e.target.value })}
              />
            </Field>
            <Field label="Descrição">
              <textarea
                className="input-base min-h-[140px] font-mono text-sm"
                value={msg.description ?? ''}
                onChange={(e) => update({ description: e.target.value })}
              />
            </Field>
            <Field label="Rodapé">
              <input
                className="input-base"
                value={msg.footer ?? ''}
                onChange={(e) => update({ footer: e.target.value })}
              />
            </Field>
            <div className="flex flex-wrap gap-1.5 pt-1">
              {VARS.map((v) => (
                <button
                  key={v}
                  type="button"
                  className="badge badge-primary hover:opacity-80 cursor-pointer"
                  onClick={() => update({ description: (msg.description ?? '') + ' ' + v })}
                >
                  {v}
                </button>
              ))}
            </div>
          </FieldGroup>

          <FieldGroup title="Visual">
            <Field label="Cor">
              <div className="flex items-center gap-3">
                <input
                  type="color"
                  className="h-10 w-14 rounded cursor-pointer bg-transparent border border-[#36393f]"
                  value={toHex(msg.color)}
                  onChange={(e) => update({ color: fromHex(e.target.value) })}
                />
                <span className="text-[#b9bbbe] text-sm font-mono">{toHex(msg.color)}</span>
              </div>
            </Field>
            <Field label="Imagem (thumbnail)">
              <input
                className="input-base"
                placeholder="https://..."
                value={msg.thumbnail ?? ''}
                onChange={(e) => update({ thumbnail: e.target.value })}
              />
            </Field>
            <Field label="Imagem grande (banner)">
              <input
                className="input-base"
                placeholder="https://..."
                value={msg.image ?? ''}
                onChange={(e) => update({ image: e.target.value })}
              />
            </Field>
          </FieldGroup>
        </div>

        <div>
          <p className="text-sm font-medium text-[#b9bbbe] mb-2">Prévia</p>
          <div
            className="rounded-lg bg-[#2b2d31] p-4 border-l-4 sticky top-24"
            style={{ borderColor: toHex(msg.color) }}
          >
            {msg.thumbnail && (
              <img src={msg.thumbnail} alt="" className="w-16 h-16 rounded-full float-right ml-3 object-cover" />
            )}
            <p className="font-semibold text-white mb-1">{preview.title || '(sem título)'}</p>
            <p className="text-sm text-[#dcddde] whitespace-pre-wrap">{preview.description}</p>
            {msg.image && <img src={msg.image} alt="" className="mt-3 rounded-lg w-full object-cover max-h-48" />}
            {msg.footer && <p className="text-xs text-[#949ba4] mt-3 border-t border-white/5 pt-2">{msg.footer}</p>}
          </div>
        </div>
      </div>
    </ModuleShell>
  );
}
