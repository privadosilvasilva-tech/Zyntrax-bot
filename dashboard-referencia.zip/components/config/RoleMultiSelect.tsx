'use client';

import { useEffect, useState } from 'react';
import { X } from 'lucide-react';

type Role = { id: string; name: string };

export function RoleMultiSelect({
  guildId,
  value,
  onChange,
}: {
  guildId: string;
  value: (string | number)[];
  onChange: (value: string[]) => void;
}) {
  const [roles, setRoles] = useState<Role[]>([]);

  useEffect(() => {
    fetch(`/api/guilds/${guildId}/roles`)
      .then((res) => res.json())
      .then((json) => setRoles(json.roles ?? []))
      .catch(() => setRoles([]));
  }, [guildId]);

  const selectedIds = value.map(String);
  const selected = roles.filter((r) => selectedIds.includes(r.id));
  const available = roles.filter((r) => !selectedIds.includes(r.id));

  return (
    <div className="space-y-2">
      <div className="flex flex-wrap gap-2 min-h-[32px]">
        {selected.length === 0 && <span className="text-sm text-[#72767d]">Nenhum cargo liberado</span>}
        {selected.map((r) => (
          <span key={r.id} className="badge badge-primary gap-1.5">
            @{r.name}
            <button type="button" onClick={() => onChange(selectedIds.filter((id) => id !== r.id))}>
              <X size={12} />
            </button>
          </span>
        ))}
      </div>
      <select
        className="input-base"
        value=""
        onChange={(e) => {
          if (e.target.value) onChange([...selectedIds, e.target.value]);
        }}
      >
        <option value="">+ Adicionar cargo liberado...</option>
        {available.map((r) => (
          <option key={r.id} value={r.id}>
            @{r.name}
          </option>
        ))}
      </select>
    </div>
  );
}
