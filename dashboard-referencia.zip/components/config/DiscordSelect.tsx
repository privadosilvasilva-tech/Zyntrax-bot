'use client';

import { useEffect, useState } from 'react';

type Option = { id: string; name: string };

export function DiscordSelect({
  guildId,
  kind,
  value,
  onChange,
  placeholder = 'Selecione...',
  allowEmpty = true,
}: {
  guildId: string;
  kind: 'channels' | 'roles';
  value: string | null | undefined;
  onChange: (value: string | null) => void;
  placeholder?: string;
  allowEmpty?: boolean;
}) {
  const [options, setOptions] = useState<Option[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    fetch(`/api/guilds/${guildId}/${kind}`)
      .then((res) => res.json())
      .then((json) => {
        if (cancelled) return;
        setOptions(json[kind] ?? []);
      })
      .catch(() => {
        if (!cancelled) setOptions([]);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [guildId, kind]);

  const prefix = kind === 'channels' ? '#' : '@';

  return (
    <select
      className="input-base"
      value={value ?? ''}
      onChange={(e) => onChange(e.target.value || null)}
      disabled={loading}
    >
      <option value="">{loading ? 'Carregando...' : placeholder}</option>
      {allowEmpty && !loading && <option value="">— nenhum —</option>}
      {options.map((opt) => (
        <option key={opt.id} value={opt.id}>
          {prefix}
          {opt.name}
        </option>
      ))}
    </select>
  );
}
