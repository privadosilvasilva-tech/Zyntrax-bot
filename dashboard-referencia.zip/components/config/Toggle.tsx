'use client';

export function Toggle({
  checked,
  onChange,
  label,
  description,
}: {
  checked: boolean;
  onChange: (value: boolean) => void;
  label?: string;
  description?: string;
}) {
  const button = (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      data-on={checked}
      className="toggle"
      onClick={() => onChange(!checked)}
    >
      <span className="toggle-thumb" />
    </button>
  );

  if (!label) return button;

  return (
    <div className="flex items-center justify-between gap-4">
      <div>
        <p className="font-medium text-[#dcddde]">{label}</p>
        {description && <p className="text-sm text-[#b9bbbe]">{description}</p>}
      </div>
      {button}
    </div>
  );
}
