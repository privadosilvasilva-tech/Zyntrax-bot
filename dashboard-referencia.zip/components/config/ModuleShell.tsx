'use client';

import { ReactNode } from 'react';
import { SaveState } from './useModuleConfig';
import { SaveIndicator } from './SaveIndicator';

export function ModuleShell({
  title,
  description,
  state,
  error,
  children,
}: {
  title: string;
  description: string;
  state: SaveState;
  error?: string | null;
  children: ReactNode;
}) {
  return (
    <div className="animate-fade-in">
      <div className="flex flex-wrap items-start justify-between gap-3 mb-6">
        <div>
          <h2 className="text-2xl font-bold text-white">{title}</h2>
          <p className="text-[#b9bbbe] text-sm mt-1">{description}</p>
        </div>
        <SaveIndicator state={state} error={error} />
      </div>
      {children}
    </div>
  );
}

export function FieldGroup({ title, children }: { title?: string; children: ReactNode }) {
  return (
    <div className="glow-card p-5 space-y-4 mb-5">
      {title && <h3 className="font-semibold text-white text-sm uppercase tracking-wide text-[#5865f2]">{title}</h3>}
      {children}
    </div>
  );
}

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="block text-sm font-medium text-[#dcddde] mb-1.5">{label}</span>
      {children}
    </label>
  );
}
