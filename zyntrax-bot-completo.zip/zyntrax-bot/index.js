const { Client, GatewayIntentBits } = require('discord.js');

// Validação de segurança
if (!process.env.DISCORD_TOKEN) {
    console.error('ERRO: DISCORD_TOKEN não configurado!');
    process.exit(1);
}

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds, // Apenas Guilds é obrigatório para comandos básicos
        GatewayIntentBits.GuildMessages // Necessário apenas se usar !ping em chats
    ]
});

client.once('ready', () => {
    console.log(`Zyntrax Online: ${client.user.tag}`);
});

client.on('messageCreate', async (msg) => {
    if (msg.author.bot || msg.content !== '!ping') return;
    await msg.reply('Pong!');
});

// Previne crash por erro não tratado
process.on('unhandledRejection', err => console.error(err));

client.login(process.env.DISCORD_TOKEN);
