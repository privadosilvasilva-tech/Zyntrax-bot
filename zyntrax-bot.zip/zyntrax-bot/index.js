require('dotenv').config();
const { Client, GatewayIntentBits } = require('discord.js');

// Validação de segurança: impede inicialização sem token
if (!process.env.DISCORD_TOKEN) {
    console.error(' ERRO CRÍTICO: DISCORD_TOKEN não configurado nas variáveis de ambiente!');
    process.exit(1);
}

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent
    ]
});

client.once('ready', () => {
    console.log(`✅ Zyntrax Bot online como ${client.user.tag}`);
});

client.on('messageCreate', async (message) => {
    if (message.author.bot) return;
    
    if (message.content === '!ping') {
        await message.reply('🏓 Pong! Latência: ' + Date.now() - message.createdTimestamp + 'ms');
    }
});

client.login(process.env.DISCORD_TOKEN);
